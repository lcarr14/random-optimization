# -*- coding: utf-8 -*-
"""
Created on Sat Oct 16 21:27:58 2021

@author: liamc
"""

import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler, OneHotEncoder
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import mlrose_hiive as mh
import random as rd
import time as t
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score

#Helper functions for data_init
def encoding(df):
    label = LabelEncoder()
    for c in df.select_dtypes("object"):
        df[c]=df[c].astype("str")
        df[c]=label.fit_transform(df[c])
    return df

def imputation(df):
    df = df.fillna(df.median())
    df = df.dropna()
    return df

def preprocessing(df):
    df = encoding(df)
    df = imputation(df) 

    return df

#data_init function
def data_init():
    #exam data sorting
    exam_scores = pd.read_csv("student_exam_data/student_performance_data.csv")
    exam_titles = ["race/ethnicity","parental level of education","lunch","test preparation course","sex","reading score percentage","writing score percentage","math percentage"]
    exam_scores = exam_scores.reindex(columns = exam_titles)
    exam_scores = preprocessing(exam_scores)
    pre_split = exam_scores.to_numpy()
    y_pre = pre_split[:,4]
    feat_pre = np.delete(pre_split, 4, 1)
    X_train, X_test, y_train, y_test = train_test_split(feat_pre, y_pre, \
                                                    test_size = 0.2, random_state = 3)
        
    # Normalize feature data
    scaler = MinMaxScaler()
    
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # One hot encode target values
    one_hot = OneHotEncoder()
    
    y_train_hot = one_hot.fit_transform(y_train.reshape(-1, 1)).todense()
    y_test_hot = one_hot.transform(y_test.reshape(-1, 1)).todense()
    return X_train_scaled, X_test_scaled, y_train_hot, y_test_hot

def single_model(algo, x_train, x_test, y_train, y_test):
    x_train, x_test, y_train, y_test = data_init()
    nn_model = mh.NeuralNetwork(hidden_nodes = [2], activation = 'relu', \
                                 algorithm = algo, max_iters = 1001, \
                                 bias = True, is_classifier = True, learning_rate = 0.0001, \
                                 early_stopping = True, clip_max = 5, max_attempts = 100, \
                                 random_state = 3, curve=True)
        
    nn_model.fit(x_train, y_train)
        
    # Predict labels for train set and assess accuracy
    y_train_pred = nn_model.predict(x_train)
    y_train_accuracy = accuracy_score(y_train, y_train_pred)
    
    # Predict labels for test set and assess accuracy
    y_test_pred = nn_model.predict(x_test)
    y_test_accuracy = accuracy_score(y_test, y_test_pred)
    print(nn_model.fitness_curve)
    return y_train_accuracy, y_test_accuracy, nn_model.fitness_curve

def acc_experiment():
    # Initialize neural network object and fit object
    x_train, x_test, y_train, y_test = data_init()
    algos = ['random_hill_climb', 'simulated_annealing', 'genetic_alg', 'gradient_descent']
    results_list = []
    fitness_curves = []
    for i in range(len(algos)):
        acc_train, acc_test, fcurve = single_model(algos[i], x_train, x_test, y_train, y_test)
        results_list.append(acc_train)
        results_list.append(acc_test)
        fitness_curves.append(fcurve)
    final_results = np.array([results_list]).reshape((4,2))
     
    X_axis = np.arange(len(algos))
    plt.bar(X_axis - 0.2, final_results[:,0], 0.4, label = 'Training')
    plt.bar(X_axis + 0.2, final_results[:,1], 0.4, label = 'Testing')
      
    plt.xticks(X_axis, algos)
    plt.xlabel("Optimizations")
    plt.ylabel("Accuracy")
    plt.title("Neural Network Accuracy with different Optimization Techniques")
    plt.legend()
    plt.show()
    
    for k in range(len(fitness_curves) - 1):
        iteration = fitness_curves[k]
        x_ax = np.arange(1, len(iteration) + 1)
        fig, ax = plt.subplots()
        ax.set_xlabel("Iterations")
        ax.set_ylabel("Fitness")
        ax.set_title("Fitness vs Iteration of Neural network with Random Optimization Algorithm " + algos[k])
        ax.plot(x_ax, iteration[:,0], marker='o', drawstyle="steps-post")
        ax.legend()
        plt.show()
        
        iteration = fitness_curves[k]
        x_ax = np.arange(1, len(iteration) + 1)
        fig, ax = plt.subplots()
        ax.set_xlabel("Iterations")
        ax.set_ylabel("Fitness")
        ax.set_title("Fitness vs Iteration of Neural network with Random Optimization Algorithm " + algos[k])
        ax.plot(iteration[:,1], iteration[:,0], marker='x', drawstyle="steps-post")
        ax.legend()
        plt.show()
    
    return 

def main():
    acc_experiment()
    
    return

if __name__ == "__main__":
    main()