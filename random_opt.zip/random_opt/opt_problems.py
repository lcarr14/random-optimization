# -*- coding: utf-8 -*-
"""
Created on Mon Oct 11 13:31:36 2021

@author: liamc
"""

import mlrose_hiive as mh
import numpy as np
import random as rd
import time as t
import matplotlib.pyplot as plt

"""
This code creates three optimization problem domains and attempts to solve each
problem using four algorithms:
    Randomized hill climbing
    Simulated annealing
    Genetic Algorithms
    MIMIC
    
These problems are over only discrete parameter spaces, with each problem
attempting to highlight advantages of a given algorithm:
    1st problem: Genetic Algorithms
    2nd problem: Simulated Annealing
    3rd problem: MIMIC
    
Because of this, these problems are selected
    1st problem: Queens problem, as the chess board is essentially an 8x8 bit plane, and bit strings were shown to fit genetic algos very well
    2nd problem: 6 peaks, as it is easy to get trapped in local optima, which simulated annealing and it's temperature funct excel at
    3rd problem: k-color, as the structure of the graph is crucial to solving, which MIMIC excels at
    
Results taken from each run of each algorithm on each problem
    Problem (x3)
        Algorithm (x4)
            how well the algorithm does (the best fitness)
            the speed in which the algorithm performs
            the number of iterations needed to complete a task "decently"
            
        encoded as:
            for every problem:
                4-line graph of max iters to fitness, one line per algo
                bar chart for average times of 10 iteration, randomized starting state
            
"""

def edge_gen(M, N):
    l=[(x+1,y+1) for x in range(N) for y in range(M)]
    rd.shuffle(l)
    for i in range(M * N - 1):
            for j in range (i+1,M*N): # find a compatible ...
                if l[i][0] != l[j][0]:
                    l[i+1],l[j] = l[j],l[i+1]
                    break  
            else:   # or insert otherwise.
                while True:
                    l[i],l[i-1] = l[i-1],l[i]
                    i-=1
                    if l[i][0] != l[i-1][0]: break  
    return l

def gen_queens(s_size):
    # states = np.zeros(8)
    # for i in range(states.size):
    #     row_num = rd.randint(0, (8 - 1))
    #     states[i] = row_num
    # fitness = mh.Queens()
    # discrete_opt = mh.DiscreteOpt(length= s_size,fitness_fn= fitness,maximize=False,max_val=8)
    #opt_prob = mh.QueensOpt(discrete_opt)
    opt_prob = mh.QueensOpt(length= s_size, maximize= True)
    return opt_prob

def gen_peaks(s_size):
    fitness = mh.FourPeaks()
    opt_prob = mh.DiscreteOpt(length= s_size,fitness_fn= fitness,maximize=True,max_val=8)
    return opt_prob

def gen_knap(s_size):
    weight_arr = np.zeros(s_size)
    for i in range(weight_arr.size):
        row_num = rd.randint(1, 15) #weight comparison
        weight_arr[i] = row_num
    value_arr = np.arange(1, s_size + 1)
    opt_prob = mh.KnapsackOpt(length= s_size, weights=weight_arr, values=value_arr, maximize=True)
    return opt_prob

def single_algo(algo_type, prob_domain, mi):
    state = 0
    fitness = 0
    tic = t.perf_counter()
    if(algo_type == 'rhc'):
        state, fitness, curve = mh.random_hill_climb(prob_domain, max_iters= 100)
    elif(algo_type == 'sa'):
        state, fitness, curve = mh.simulated_annealing(prob_domain, schedule= mh.ExpDecay(init_temp=50.0, exp_const=2, min_temp=0.001), max_iters= 100)
    elif(algo_type == 'ga'):
        state, fitness, curve = mh.genetic_alg(prob_domain, pop_size=50, max_iters=100, random_state = 2)
    elif(algo_type == 'mimic'):
        state, fitness, curve = mh.mimic(prob_domain, max_iters=50)
    else:
        state, fitness = "error args", 0
    time = t.perf_counter() - tic
    return [state, fitness, time]
    
def run_algos(prob_domain, mi):
    return_array = [] #indices 0 - 11 with alternating state, fitness, and time for rhc, sa, ga, and mimic in that order
    return_array += single_algo('rhc', prob_domain, mi)
    return_array += single_algo('sa', prob_domain, mi)
    return_array += single_algo('ga', prob_domain, mi)
    return_array += single_algo('mimic', prob_domain, mi)
    return return_array
    
    
def experiment():
    d_names = ["Queens", "4-Peaks", "Knapsack"]
    for k in range(3):
        time_list = []
        fit_to_its = []
        for i in range(10, 51, 5):
            domains = [gen_queens(i), gen_peaks(i), gen_knap(i)]
            domain = domains[k]   #set board size here
            it_array = run_algos(domain, i)
            if(i == 50): #append times only for 10-iteration runs
                time_list.append(it_array[2])
                time_list.append(it_array[5])
                time_list.append(it_array[8])
                time_list.append(it_array[11])
            # fitness_row = [it_array[1], it_array[4], it_array[7], it_array[10]]
            # fitness_row.append() #rhc fitness
            # fitness_row.append() #sa fitness
            # fitness_row.append() #ga fitness
            # fitness_row.append() #mimic fitness
            fit_to_its.append(it_array[1]) #rhc fitness
            fit_to_its.append(it_array[4]) #sa fitness
            fit_to_its.append(it_array[7]) #ga fitness
            fit_to_its.append(it_array[10]) #mimic fitness
            
        fit_to_it = np.array([fit_to_its]).reshape((9,4))
        print(fit_to_it) 
        
        # at this point we have a 2d array of fitnesses for each of the models, 
        # with columns being model type, and row being iteration number
        
        x_ax = range(10, 51, 5)
        fig, ax = plt.subplots()
        ax.set_xlabel("Input Problem Size")
        ax.set_ylabel("Fitness")
        ax.set_title("Fitness vs Problem Domain Size of Random Optimization Algorithms on " + d_names[k])
        ax.plot(x_ax, fit_to_it[:,0], marker='.', label="random hill climb",
                drawstyle="steps-post")
        ax.plot(x_ax, fit_to_it[:,1], marker='.', label="simulated annealing",
                drawstyle="steps-post")
        ax.plot(x_ax, fit_to_it[:,2], marker='.', label="genetic algorithm",
                drawstyle="steps-post")
        ax.plot(x_ax, fit_to_it[:,3], marker='.', label="mimic",
                drawstyle="steps-post")
        ax.legend()
        plt.show()
        
        #time plots
        t_alg_names = ["rhc", "sa", "ga", "mimic"]
        fig = plt.figure()
        ax = fig.add_axes([0,0,1,1])
        ax.bar(t_alg_names, time_list)
        plt.show()
    return
    
    
def main():
    experiment()   
    
    return

if __name__ == "__main__":
    main()