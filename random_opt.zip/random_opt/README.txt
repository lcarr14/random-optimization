Code information://
	Python Version: 3.8//
	IDE used: Spyder (Anaconda)//
Use://
	Go to: https://github.com/lcarr14/___.git//
	Download zip and unzip//
	Open "opt_problems.py" for 4 random optimization problem analysis//
	Open "nn_opt.py" for neural network random optimization analysis//
	run the .py program//
	graphs should generate as program runs through different algorithms, these are the primary tools of analysis//